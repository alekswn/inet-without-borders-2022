# Installing cjdns on SmartOS

** currently broken - wip

    pkgin in scmgit-1.8.3.1
    pkgin in gcc47-4.7.3nb1
    pkgin in cmake-2.8.11
    pkgin in gmake-3.82nb7
    git clone git://github.com/cjdelisle/cjdns.git
    cd cjdns/
    ./do

