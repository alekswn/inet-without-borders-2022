NYC Meshnet
===========

**Website** : [nycmesh.net](https://nycmesh.net/blog/starting-with-the-basics/)

**IRC Channel** : [#nycmeshnet on EFNet](irc://irc.efnet.org/#nycmeshnet)
