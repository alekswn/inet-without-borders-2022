## Iface.h

TODO: This lacks context. What is an interface?

Check out the new `[Iface.h]`(https://github.com/hyperboria/cjdns/blob/master/interface/Iface.h) which replaced the old `Interface.h`.

It features a manual tail call optimization which will likely be reused throughout the codebase.

See [the flag used to turn on the optimization](https://github.com/hyperboria/cjdns/blob/master/interface/Iface.h#L65).

