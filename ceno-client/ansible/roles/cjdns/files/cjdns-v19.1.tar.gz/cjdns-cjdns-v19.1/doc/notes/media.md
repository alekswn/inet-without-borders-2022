# Cjdns in the media

## English

http://www.wired.com/2013/10/thompson/

http://marsocial.com/2015/07/the-declaration-of-internet-independence/

http://curiousmatic.com/meet-the-young-techies-who-want-to-change-the-way-nyc-connects-to-the-internet/

https://en.wikipedia.org/wiki/Cjdns

https://www.youtube.com/watch?v=sCFmzGknUew

http://www.newscientist.com/article/mg21929294.500-meshnet-activists-rebuilding-the-internet-from-scratch.html

https://www.fsf.org/blogs/licensing/interview-with-caleb-james-delisle-of-cjdns

http://yourlisten.com/opencu/caleb-james-delisle-of-on-cjdns-a-new-internet-in-8-minutes

http://resources.infosecinstitute.com/project-meshnet/

http://www.techhive.com/article/259959/project_meshnet_aims_to_build_a_censorship_free_alternative_to_the_internet.html

http://www.kurzweilai.net/project-meshnet-aims-to-build-a-censorship-free-alternative-to-the-internet

http://www.sync-blog.com/sync/2012/08/would-a-censorship-free-internet-be-a-good-idea.html

http://realitysandwich.com/160579/meshnet_possible_uncensored_internet_alternative/

http://www.dutecs.com/how-to-stop-the-nsa-spying-on-your-data/

http://nxter.org/hyperboria-adopts-nxt-aliases-for-dns-solution/ 

http://sett.com/alansjourney/52637

[Does the hacker news count as media?](https://news.ycombinator.com/item?id=9843373)

http://www.fastcompany.com/3044686/mesh-networks-and-the-local-internet-movement

## ???

http://www.zive.cz/clanky/sest-alternativnich-a-zapomenutych-internetu/sc-3-a-169392/default.aspx

## German???

http://scratchbook.ch/2013/06/24/cjdns/

http://www.nzz.ch/digital/neustart-1.18140845

## In Russian

http://habrahabr.ru/post/181862/

http://habrahabr.ru/post/182652/

http://habrahabr.ru/post/183606/

