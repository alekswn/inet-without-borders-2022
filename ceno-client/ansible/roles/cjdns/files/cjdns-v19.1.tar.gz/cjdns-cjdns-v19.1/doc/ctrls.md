# 3rd Party Tools for managing/working with cjdns

To automate some simple tasks with cjdns, there are a lot of scripts that people use. Here's just a few:

+ https://github.com/kpcyrd/yrd
  + Displays nodeinfo
  + Shows your neighbors and their neighbors
  + Show bandwidth
  + Ping nodes
  + Dump nodestore
  + Show uplinks of a node

+ https://github.com/noway421/cjdmaid
+ https://github.com/inhies/cjdcmd
+ https://github.com/ehmry/cjdcmd-ng
+ tcjdns (ask prurigro)
