VirginiaMesh
============

**Our Goals:**

* Create smaller meshes in Virginia when we reach a larger amount of members

* Connect Virginians up to Hyperboria

* Increase public awareness about CJDNS, Hyperboria, and Project Meshnet

* Foster a community of knowing and helping others, in whatever way possible

* Foster trust in our community, because without trust, we are nothing.


**Subreddit**: [/r/VirginiaMesh](https://reddit.com/r/VirginiaMesh)

**Main Contact:** [Caleb Smith](mailto:caleb@calebsmith.net)

**IRC Channel:** [#VirginiaMesh on EFNet](irc://irc.choopa.net/virginiamesh)

**Mailing List:** http://lists.projectmesh.net/virginia
