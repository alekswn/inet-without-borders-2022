Seattle Meshnet
============

**Subreddit**: [/r/SeattleMeshnet](https://www.reddit.com/r/SeattleMeshnet)

**IRC Channel:** [#SeattleMeshnet on EFNet](irc://irc.efnet.org/#seattlemeshnet)

**Mailing List:** [click me](https://lists.projectmesh.net/seattle)
