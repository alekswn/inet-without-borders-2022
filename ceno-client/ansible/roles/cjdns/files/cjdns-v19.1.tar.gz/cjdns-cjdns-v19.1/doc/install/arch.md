# Installing cjdns on arch

	pacman -S cjdns
	systemctl enable cjdns
	systemctl start cjdns

