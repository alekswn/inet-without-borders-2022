## What can we do to make everything work better?


```
19:42 < ansuz> I'm thinking I'm gonna make an official "welcome to hyperboria package"
19:43 < ansuz> and get everyone on efnet to point to that instead of peers.txt or my faq
19:44 < ansuz> detail my findings from these interviews, tools that are commonly used, where you can find public peers, how to debug
19:44 < ansuz> where to look for documentation, how to explore the network
19:44 < ansuz> how to format bug reports, where to report them

19:47 <@larsg> what can we do to make things better? -- invent a new name for cjdns

19:50 <@larsg> what can we do to make things better? -- develop apps which fit the p2p character of the network

```


